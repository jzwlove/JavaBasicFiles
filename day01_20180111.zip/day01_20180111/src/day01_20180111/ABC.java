package day01_20180111;

public class ABC {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
